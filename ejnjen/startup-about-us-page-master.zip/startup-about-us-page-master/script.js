$(document).ready(function(){ 
   $(function () {
      $('[data-toggle="tooltip"]').tooltip()
      });
  
      // Initialize popover component
      $(function () {
      $('[data-toggle="popover"]').popover()
      });
});
